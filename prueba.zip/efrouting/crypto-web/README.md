# iniciar el proyecto 
para que el poroyecto funcione tiene que ir a config.js y agregar una crecencial de iam donde tenga acesso a dynamodb
```
npm install
```
```
npm run build
```

# Crear docker 
## crear imagen
```
docker build -t mi_app_nginx .
```
## correr imagen
```
docker run -d -p 80:80 mi_app_nginx
```