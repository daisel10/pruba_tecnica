const configEnv1 = {
    
}

export default configEnv1;