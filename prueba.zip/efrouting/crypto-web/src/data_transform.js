export const data_transform =(cryptoData)=>{

    const bitcoinData = cryptoData.filter(item => item.crypto.S === 'BTC');
    const ethereumData = cryptoData.filter(item => item.crypto.S === 'ETH');

    // Crear los arrays de fechas y precios para Bitcoin y Ethereum
    const updatedBitcoin = bitcoinData.map(item => new Date(item.updated.S));
    const priceBitcoin = bitcoinData.map(item => parseFloat(item.price.S));


    const updatedEthereum = ethereumData.map(item => new Date(item.updated.S));
    const priceEthereum = ethereumData.map(item => parseFloat(item.price.S));

    return {
        updatedBitcoin,
        priceBitcoin,
        updatedEthereum,
        priceEthereum
    }
}