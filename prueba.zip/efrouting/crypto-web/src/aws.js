import { DynamoDBClient, ScanCommand } from "@aws-sdk/client-dynamodb";
import configEnv1 from "../config.js";

async function data_dynamodb(){
    const dynamoClient = new DynamoDBClient({region:configEnv1.region, 
        credentials:{
                secretAccessKey: configEnv1.secretAccessKey,
                accessKeyId: configEnv1.accessKeyId,
    }})
    const command = new ScanCommand({ TableName: "crypto" });
    try {
        
        const response = await dynamoClient.send(command);
        return response.Items
    } catch (error) {
        console.log("error",error)
    }
    

    
  }
  
  export default data_dynamodb;
  