import React, { useEffect, useState } from 'react';
import Plot from 'react-plotly.js';
import data_dynamodb from './aws.js';
import { data_transform } from './data_transform.js';
import './App.css'
function App() {
  const [cryptoData, setCryptoData] = useState({
    BTC: { updatedBitcoin: [], priceBitcoin: [] },
    ETH: { updatedEthereum: [], priceEthereum: [] }
  });
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      const cryptoData = await data_dynamodb();
      
      const {updatedBitcoin, priceBitcoin,updatedEthereum,priceEthereum} = data_transform(cryptoData)
      setCryptoData({
        BTC: { updatedBitcoin, priceBitcoin },
        ETH: { updatedEthereum, priceEthereum }
      });
      console.log("🚀 ~ file: App.jsx:11 ~ App ~ cryptoData:", cryptoData)
      
      setLoading(false);
    };

    fetchData();
  }, []);


  if (loading) {
    return <p>Cargando datos...</p>;
  }

  return (
    <>
      <h1>Gráficas de precios de criptomonedas</h1>
      <div className="plot-container"> 
      <Plot
        data={[{ x: cryptoData.ETH.updatedEthereum, y: cryptoData.ETH.priceEthereum, type: 'scatter', mode: 'lines+markers', marker: { size: 8, color:'green' }, line: { shape: 'linear' } }]}
        layout={{
          width: 800,
          height: 500,
          title: 'Precio del etheteum',
          paper_bgcolor:{ color: 'black'},
          xaxis: {
            title: 'Fecha',
            type: 'date', 
          },
          yaxis: {
            title: 'USD',
            tickformat: ',.2f'
          },
        }}
      />
      </div>
      <div className="plot-container"> 
      <Plot
        data={[{ x: cryptoData.BTC.updatedBitcoin, y: cryptoData.BTC.priceBitcoin, type: 'scatter', mode: 'lines+markers', marker: { size: 8, color:'green' }, line: { shape: 'linear' } }]}
        layout={{
          width: 800,
          height: 500,
          title: 'Precio del Bitcoin',
          paper_bgcolor:{ color: 'black'},
          xaxis: {
            title: 'Fecha',
            type: 'date', 
          },
          yaxis: {
            title: 'USD',
            tickformat: ',.2f'
          },
        }}
      />
      </div>
    </>
  );
}

export default App;
