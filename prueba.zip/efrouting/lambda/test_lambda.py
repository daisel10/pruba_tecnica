import unittest
from unittest.mock import patch
from lambda_function import get_crypto_prices, store_prices_in_dynamodb, table

# Creamos una clase de pruebas
class TestLambda(unittest.TestCase):

    # Test para la función get_crypto_prices
    @patch('lambda_function.requests.get')  # Utilizamos patch para simular el objeto 'requests.get' 
    def test_get_crypto_prices(self, mock_get):
        # Definimos un diccionario con datos simulados que la función 'requests.get().json()' retornaría
        mock_data = {
            'data': {
                'BTC': {'quote': {'USD': {'price': 45000, 'last_updated': '2023-07-21'}}},
                'ETH': {'quote': {'USD': {'price': 3000, 'last_updated': '2023-07-21'}}}
            }
        }

        # Configuramos el valor de retorno de 'requests.get().json()' para que sea el diccionario simulado
        mock_get.return_value.json.return_value = mock_data

        # Llamamos a la función que queremos probar
        crypto_prices = get_crypto_prices()

        # Verificamos que la función devuelve los resultados esperados
        self.assertEqual(crypto_prices['BTC'], 45000)
        self.assertEqual(crypto_prices['BTC_updated'], '2023-07-21')
        self.assertEqual(crypto_prices['ETH'], 3000)
        self.assertEqual(crypto_prices['ETH_updated'], '2023-07-21')

    # Test para la función store_prices_in_dynamodb
    @patch.object(table, 'put_item')  # Utilizamos patch para simular el método 'put_item' del objeto 'table'
    def test_store_prices_in_dynamodb(self, mock_put_item):
        # Definimos un diccionario con datos simulados de precios
        prices = {
            'BTC': 45000,
            'BTC_updated': '2023-07-21',
            'ETH': 3000,
            'ETH_updated': '2023-07-21'
        }

        # Llamamos a la función que queremos probar
        store_prices_in_dynamodb(prices)

        # Definimos una lista con las llamadas esperadas a 'table.put_item'
        expected_calls = [
            unittest.mock.call(Item={'crypto': 'BTC', 'price': '45000', 'updated': '2023-07-21'}),
            unittest.mock.call(Item={'crypto': 'ETH', 'price': '3000', 'updated': '2023-07-21'})
        ]

        # Verificamos que se hayan realizado las llamadas esperadas a 'table.put_item'
        mock_put_item.assert_has_calls(expected_calls)

        # Verificamos que el método 'put_item' haya sido llamado dos veces (una por cada criptomoneda)
        self.assertEqual(mock_put_item.call_count, 2)

if __name__ == '__main__':
    unittest.main()
