import os
import json
import boto3
import requests


print('Loading function')
# Se Configura el cliente de DynamoDB
dynamodb = boto3.resource('dynamodb', region_name='us-east-1') # poner la region correspondiente a la tabla creada 
table_name = 'crypto'  # Reemplaza 'crypto' con el nombre de tu tabla en DynamoDB donde quieres que se te guarden los datos 
table = dynamodb.Table(table_name)

# Configura los datos de autenticación para la API de CoinMarketCap
api_key = 'tu_api_key'  # Reemplaza 'tu_api_key' con tu API Key de CoinMarketCap
headers = {
    'X-CMC_PRO_API_KEY': api_key
}

# Endpoint del API para obtener los precios de Bitcoin (BTC) y Ethereum (ETH) en CoinMarketCap
endpoint = 'https://pro-api.coinmarketcap.com/v1/cryptocurrency/quotes/latest'
# Parametros donde se le indican que monedas va a extraer
params = {
    'symbol': 'BTC,ETH'
}
# Creamos una fucncion para la optencion de los precios de Bitcoin y Ethereum a la API de CoinMarketCap
def get_crypto_prices():
    # Hacer la petición a la API de CoinMarketCap
    response = requests.get(endpoint, headers=headers, params=params)
    # Almacenar la informacion
    data = response.json()

    # Obtener los precios de Bitcoin y Ethereum desde la respuesta
    btc_price = data['data']['BTC']['quote']['USD']['price']
    btc_updated = data['data']['BTC']['quote']['USD']['last_updated']
    eth_price = data['data']['ETH']['quote']['USD']['price']
    eth_updated = data['data']['ETH']['quote']['USD']['last_updated']

    # devolmos la informacion
    return {
        'BTC': btc_price,
        'BTC_updated': btc_updated,
        'ETH': eth_price,
        'ETH_updated': eth_updated
    }
# Hacemos peticion para almacenar la informacion en DynamoDB
def store_prices_in_dynamodb(prices):
    # Almacenar los precios en la tabla de DynamoDB
    table.put_item(Item={
        'crypto': 'BTC',
        'price': str(prices['BTC']),
        'updated': str(prices['BTC_updated'])
    })
    
    table.put_item(Item={
        'crypto': 'ETH',
        'price': str(prices['ETH']),
        'updated': str(prices['ETH_updated'])
    })
# funcion que llama por defecto AWS 
def lambda_handler(event, context):
    try:
        # Obtener los precios de las criptomonedas
        crypto_prices = get_crypto_prices()

        # Almacenar los precios en DynamoDB
        store_prices_in_dynamodb(crypto_prices)

        # Preparar la respuesta en formato JSON
        response_body = {
            'BTC': crypto_prices['BTC'],
            'ETH': crypto_prices['ETH']
        }

        # Devolver la respuesta
        return {
            'statusCode': 200,
            'body': json.dumps(response_body)
        }
    # En caso de error devuelve esta respuesta
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps({'error': str(e)})
        }
